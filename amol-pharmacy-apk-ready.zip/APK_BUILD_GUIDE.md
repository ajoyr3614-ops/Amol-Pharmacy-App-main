# APK banano (Amol Pharmacy)

Ei project-e 17-ti screen-er pura app **web (React)** version-e ache. Seta Capacitor diye Android app (APK) banano hoy.
(`android/` folder-er Kotlin project-ti adha — shudhu Dashboard, POS, Summary ache — tai oti diye APK banano hoy ni.)

## Sobcheye shohoj: GitHub diye (PC-te kichu install korte hobe na)
1. GitHub-e notun repository banan, ei pura folder upload/push korun.
2. Repository-r **Actions** tab -> **Build Android APK** -> **Run workflow**.
3. 5-10 minute por run-er niche **Artifacts -> amol-pharmacy-apk** download korun, zip khulle `app-debug.apk` pabe.
4. APK phone-e pathiye install korun (Unknown sources allow korte hobe).

## PC-te nijer machine-e
Lagbe: Node 22, JDK 21, Android SDK (Android Studio).
```bash
npm install
npm run build
npx cap add android          # prothom bar-i
node scripts/patch-android.mjs
npx cap sync android
cd android && ./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
```
Code bodlale: `npm run cap:sync` cholan, tarpor abar `./gradlew assembleDebug`.

## Ki ki thik kora hoyeche
- `capacitor.config.ts` + Capacitor package add, `vite.config.ts`-e `base: './'`
- Backup: browser download WebView-te kaj kore na, tai `src/services/nativeFile.ts` diye share-sheet-e save hoy
- Memo share: Android share sheet use kore
- Camera barcode scanner-er jonno CAMERA permission auto-add hoy

## Jana shimabodhota
- Thermal/A4 **print** (`window.print()`) Android WebView-te kaj korbe na — er jonno alada print plugin lagbe.
- Data phone-er nijer storage-e (localStorage) thake; app uninstall korle muche jay, tai niyomito Backup nin.
- Google Fonts internet chara load hobe na (fallback font dekhabe).
- Eta **debug** APK. Play Store-er jonno signed release build lagbe.
- Ami ekhane Android SDK/internet na thakay build kore dekhte pari ni; GitHub Actions-e prothom run-e kono error ashle log pathan.
