import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.amol.pharmacy.app',
  appName: 'Amol Pharmacy',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
  },
};

export default config;
