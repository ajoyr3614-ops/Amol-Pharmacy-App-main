// Run after `npx cap add android`: adds the permissions the app needs (camera barcode scanner).
import { readFileSync, writeFileSync } from 'node:fs';

const file = 'android/app/src/main/AndroidManifest.xml';
let xml = readFileSync(file, 'utf8');

const block = `
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
`;

if (!xml.includes('android.permission.CAMERA')) {
  xml = xml.replace('</manifest>', `${block}</manifest>`);
  writeFileSync(file, xml);
  console.log('Added CAMERA permission to AndroidManifest.xml');
} else {
  console.log('CAMERA permission already present');
}
