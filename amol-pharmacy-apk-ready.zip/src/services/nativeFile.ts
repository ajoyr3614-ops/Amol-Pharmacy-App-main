/**
 * Saves/shares files in a way that works both in a normal browser and inside
 * the Capacitor Android app (where blob-URL downloads and navigator.share
 * are not available in the WebView).
 */
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

export const isNativeApp = (): boolean => Capacitor.isNativePlatform();

/** Save a text file. On Android it is written to cache and the share sheet opens (Save to Drive / Files / WhatsApp...). */
export async function saveTextFile(filename: string, content: string, mime = 'application/json'): Promise<void> {
  if (isNativeApp()) {
    const res = await Filesystem.writeFile({
      path: filename,
      data: content,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
    });
    await Share.share({ title: filename, url: res.uri, dialogTitle: 'Save backup' });
    return;
  }
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/** Share plain text. Returns false if nothing could be shared (caller may fall back to clipboard). */
export async function shareText(title: string, text: string): Promise<boolean> {
  if (isNativeApp()) {
    await Share.share({ title, text });
    return true;
  }
  if (navigator.share) {
    await navigator.share({ title, text });
    return true;
  }
  return false;
}
